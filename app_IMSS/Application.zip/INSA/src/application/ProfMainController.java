package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ProfMainController {

	@FXML
    private ComboBox<Filiere> comboFilliere;

    @FXML
    private ComboBox<Semestre> comboSemestre;

    @FXML
    private ComboBox<Module> comboModule;
    
    @FXML
    private ComboBox<Matiere> comboMatiere;

    @FXML
    private TextField stp_tf;

    @FXML
    private TextField cee_tf;

    @FXML
    private TextField cetp_tf;

    @FXML
    private ComboBox<?> comboSession;
    
    public void initialize(){
    	loadFilieres();
    	loadSemestres();
    }
    
    public void loadFilieres()
    {
    	ArrayList<Filiere> al=DBManager.getFilieres();
    	comboFilliere.getItems().clear();
    	comboFilliere.getItems().addAll(al);

    }
    
    public void loadSemestres()
    {
    	ArrayList<Semestre> al=DBManager.getSemestres();
    	comboSemestre.getItems().clear();
    	comboSemestre.getItems().addAll(al);

    }
    
    public void loadModules()
    {
    	if(comboSemestre.getSelectionModel().getSelectedItem()!=null && comboFilliere.getSelectionModel().getSelectedItem()!=null)
    	{
    		ArrayList<Module> al=DBManager.getModules(comboFilliere.getSelectionModel().getSelectedItem().id,comboSemestre.getSelectionModel().getSelectedItem().id);
        	comboModule.getItems().clear();
        	comboModule.getItems().addAll(al);
    	}

    }
    
    public void loadMatieres()
    {
    	if(comboModule.getSelectionModel().getSelectedItem()!=null )
    	{
    		ArrayList<Matiere> al=DBManager.getMatieres(comboModule.getSelectionModel().getSelectedItem().id);
        	comboMatiere.getItems().clear();
        	comboMatiere.getItems().addAll(al);
    	}

    }
    
    public void FillMatiereInfos()
    {
    	if(comboMatiere.getSelectionModel().getSelectedItem()!=null)
    	{
    		Matiere m=comboMatiere.getSelectionModel().getSelectedItem();
        	String s1=""+m.nbr_tp;
        	String s2=""+m.coefecrit;
        	String s3=""+m.coeftp;
        	stp_tf.setText(s1);
        	cee_tf.setText(s2);
        	cetp_tf.setText(s3);
    	}
    	else
    	{
    		stp_tf.setText("");
        	cee_tf.setText("");
        	cetp_tf.setText("");
    	}
    	
    }
    
    public void UpdateMatiere()
    {
    	if(comboMatiere.getSelectionModel().getSelectedItem()!=null)
    	{
        	DBManager.updateMatiere(comboMatiere.getSelectionModel().getSelectedItem().id,Integer.parseInt(stp_tf.getText()),Integer.parseInt(cee_tf.getText()),Integer.parseInt(cetp_tf.getText()));
        	//Alert
        	{
        		Alert alert = new Alert(AlertType.INFORMATION);
	            alert.setTitle("Success");
	            alert.setHeaderText(null);
	            alert.setContentText("Matiere mise � jour!");
	     
	            alert.showAndWait();
        	}
    	}
    	else
    	{
    		Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Selectionnez d'abord une matiere!");
     
            alert.showAndWait();
    	}
    }
    
    public void EntreSeancesTP(ActionEvent actionEvent) throws IOException
    {
    	if(comboMatiere.getSelectionModel().getSelectedItem()!=null)
    	{
    		ArrayList<Evaluation> al=DBManager.getEvaluations(comboMatiere.getSelectionModel().getSelectedItem().id);
    		
    		EntreSeancesTPController.al=al;
    		
    		Node  source = (Node)  actionEvent.getSource(); 
    	    Stage stage  = (Stage) source.getScene().getWindow();
    	    Main.setRoot("EntreSeancesTP");

    	    stage.setResizable(false);
    	}
    	else
    	{
    		Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Selectionnez d'abord une matiere!");
     
            alert.showAndWait();
    	}

    }
    
    public void SaisirNoteTP(ActionEvent actionEvent) throws IOException
    {
    	if(comboMatiere.getSelectionModel().getSelectedItem()!=null)
    	{
    		ArrayList<Evaluation> al=DBManager.getEvaluations(comboMatiere.getSelectionModel().getSelectedItem().id);
    		
    		SaisirNoteTPController.al=al;
    		
    		Node  source = (Node)  actionEvent.getSource(); 
    	    Stage stage  = (Stage) source.getScene().getWindow();
    	    Main.setRoot("SaisirNoteTP");

    	    stage.setResizable(false);
    	}
    	else
    	{
    		Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Selectionnez d'abord une matiere!");
     
            alert.showAndWait();
    	}

    }
    
    public void SaisirNoteEcrit(ActionEvent actionEvent) throws IOException
    {
    	if(comboMatiere.getSelectionModel().getSelectedItem()!=null)
    	{
    		ArrayList<Evaluation> al=DBManager.getEvaluations(comboMatiere.getSelectionModel().getSelectedItem().id);
    		
    		SaisirNoteEcritController.al=al;
    		
    		Node  source = (Node)  actionEvent.getSource(); 
    	    Stage stage  = (Stage) source.getScene().getWindow();
    	    Main.setRoot("SaisirNoteEcrit");

    	    stage.setResizable(false);
    	}
    	else
    	{
    		Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Selectionnez d'abord une matiere!");
     
            alert.showAndWait();
    	}

    }
    
    public void Afficher() throws IOException
    {
    	if(comboMatiere.getSelectionModel().getSelectedItem()!=null)
    	{
			ArrayList<Evaluation> al=DBManager.getEvaluations(comboMatiere.getSelectionModel().getSelectedItem().id);
	
			MethodeAffichageController.al=al;
	
	    	Stage stage=new Stage();
	    	FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("MethodeAffichage.fxml"));
	    	Scene scene = new Scene(fxmlLoader.load(), 350, 150);
			stage.setScene(scene);
			stage.show();
    	}
    	else
    	{
    		Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Selectionnez d'abord une matiere!");
     
            alert.showAndWait();
    	}
    }
}
