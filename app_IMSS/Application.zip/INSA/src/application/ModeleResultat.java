package application;

public class ModeleResultat {
	
	String module,matiere;
	float note_matiere;
	float note_module;
	String validation;
	
	public ModeleResultat(String module, String matiere, float note_matiere, float note_module) {
		super();
		this.module = module;
		this.matiere = matiere;
		this.note_matiere = note_matiere;
		this.note_module = note_module;
		this.validation = note_module<10?"Non Valid�":"Valid�";
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getMatiere() {
		return matiere;
	}

	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}

	public float getNote_matiere() {
		return note_matiere;
	}

	public void setNote_matiere(float note_matiere) {
		this.note_matiere = note_matiere;
	}

	public float getNote_module() {
		return note_module;
	}

	public void setNote_module(float note_module) {
		this.note_module = note_module;
	}

	public String getValidation() {
		return validation;
	}

	public void setValidation(String validation) {
		this.validation = validation;
	}
	
	
	

}
