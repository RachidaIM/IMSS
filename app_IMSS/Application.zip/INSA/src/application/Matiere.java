package application;

public class Matiere {

	int id,coeftp,coefecrit,id_module , nbr_tp;
	String nom;
	
	
	public Matiere(int id, int coeftp, int coefecrit, int id_module,int nbr_tp ,String nom) {
		super();
		this.id = id;
		this.coeftp = coeftp;
		this.coefecrit = coefecrit;
		this.id_module = id_module;
		this.nbr_tp=nbr_tp;
		this.nom = nom;
	}

	@Override
	public String toString() {
		return nom ;
	}
	
	
}
