package application;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.print.PageLayout;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PageImpressionController {

	@FXML
    private VBox myVbox2;
	
    @FXML
    private Label titile;
    

    @FXML
    private HBox myHbox;
    
    public static ArrayList<Evaluation> al=null;
    
    public void initialize()
    {
    	if(al!=null)
    	{
    	    TableView tableView = new TableView();
    		
    		TableColumn<ModeleAffichage, Integer> column0 = new TableColumn<>("CNE");
            column0.setCellValueFactory(new PropertyValueFactory<>("CNE"));
            
            TableColumn<ModeleAffichage, String> column1 = new TableColumn<>("Nom");
            column1.setCellValueFactory(new PropertyValueFactory<>("nom"));
            
            TableColumn<ModeleAffichage, String> column2 = new TableColumn<>("Pr�nom");
            column2.setCellValueFactory(new PropertyValueFactory<>("prenom"));

            TableColumn<ModeleAffichage, Float> column3 = new TableColumn<>("Note");
            column3.setCellValueFactory(new PropertyValueFactory<>("note"));
            
            TableColumn<ModeleAffichage, String> column4 = new TableColumn<>("Validation");
            column4.setCellValueFactory(new PropertyValueFactory<>("validation"));
            
                        
            tableView.getColumns().add(column0);
            tableView.getColumns().add(column1);
            tableView.getColumns().add(column2);
            tableView.getColumns().add(column3);
            tableView.getColumns().add(column4);
            
            for(int i=0;i<al.size();i++)
            {
            	Etudiant e=DBManager.getEtudiant(al.get(i).CNE);
            	Matiere m=DBManager.getMatiere(al.get(i).id_matiere);
            	float n=(al.get(i).note_ecrit*m.coefecrit+al.get(i).note_tp*m.coeftp)/(m.coefecrit+m.coeftp);
            	ModeleAffichage ma=new ModeleAffichage(e.CNE,e.nom,e.prenom,n);
            	tableView.getItems().add(ma);
            }
            titile.setText("Resultat du module "+DBManager.getMatiere(al.get(0).id_matiere));

            myHbox.getChildren().add(tableView);
            

            
    	}
    	
    }
    
    public void print()
    {
    	PrinterJob job = PrinterJob.createPrinterJob();
        if(job != null){

		  job.printPage(myVbox2);
		  job.endJob();
        }
    }
    
}
