package application;

public class Filiere {

	int id;
	String nom;
	public Filiere(int id, String nom) {
		super();
		this.id = id;
		this.nom = nom;
	}
	@Override
	public String toString() {
		return nom ;
	}
}
