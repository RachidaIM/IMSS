package application;

public class User {

	public int id;
	public String nom,mdp,role;
	
	public User(int id, String nom, String mdp, String role) {
		super();
		this.id = id;
		this.nom = nom;
		this.mdp = mdp;
		this.role = role;
	}
}
