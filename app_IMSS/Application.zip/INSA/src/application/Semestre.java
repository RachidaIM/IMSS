package application;

public class Semestre {

	int id;
	String nom;
	
	public Semestre(int id, String nom) {
		super();
		this.id = id;
		this.nom = nom;
	}

	@Override
	public String toString() {
		return nom;
	}
	
}
