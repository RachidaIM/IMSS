package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MethodeAffichageController {
	
    @FXML
    private RadioButton visualRadio;

    @FXML
    private RadioButton ImprRadio;
	
	int selected=0;
	
	public static ArrayList<Evaluation> al=null;
	
	public void selectAffichage()
	{
		selected=0;
		ImprRadio.setSelected(false);

	}
	
	public void selectImpression()
	{
		selected=1;
		visualRadio.setSelected(false);
	}
	
	public void OKBtnHandler(ActionEvent actionEvent) throws Exception
	{
		if(selected==0)
		{
			AffichageController.al=al;
			
	    	Stage stage=new Stage();
	    	FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Affichage.fxml"));
	    	Scene scene = new Scene(fxmlLoader.load(), 700, 520);
			stage.setScene(scene);
			stage.show();
			
			Node  source = (Node)  actionEvent.getSource(); 
    	    Stage stage2  = (Stage) source.getScene().getWindow();
    	    stage2.close();
    	    
		}
		else
		{
			if(al!=null)
	    	{
				PageImpressionController.al=al;
				
				Stage stage=new Stage();
		    	FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PageImpression.fxml"));
		    	fxmlLoader.load(); //to invoke the initialize methode
		    	PageImpressionController pic=fxmlLoader.getController();
		    	pic.print();

				Node  source = (Node)  actionEvent.getSource(); 
	    	    Stage stage2  = (Stage) source.getScene().getWindow();
	    	    stage2.close();
	    	}
			
		}
	}
}
