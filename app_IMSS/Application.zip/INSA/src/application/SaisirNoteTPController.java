package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class SaisirNoteTPController {

	@FXML
    private TextField nomtf;

    @FXML
    private TextField prenomtf;

    @FXML
    private TextField filieretf;

    @FXML
    private TextField cnetf;

    @FXML
    private TextField noteTP_tf;
    
	public static ArrayList<Evaluation> al=null;
	int current=0;
	
    public void initialize(){
    	if(al.size()>0)
    	{
        	current=0;
        	load(current);
    	}
    }

    public void load(int index)
    {
    	Etudiant e=DBManager.getEtudiant(al.get(index).CNE);
    	nomtf.setText(e.nom);
    	prenomtf.setText(e.prenom);
    	cnetf.setText(e.CNE+"");
    	noteTP_tf.setText(al.get(current).note_tp+"");
    	Filiere f=DBManager.getFiliere(e.id_filiere);
    	filieretf.setText(f.nom);
    }

    public void loadNext()
    {
    	if(current+1<al.size())
    	{
    		current++;
    		load(current);
    	}	
    }
    
    public void loadPrevious()
    {
    	if(current>0)
    	{
    		current--;
    		load(current);
    	}	
    }
    
    public void quit(ActionEvent actionEvent) throws IOException
    {
    	Node  source = (Node)  actionEvent.getSource(); 
	    Stage stage  = (Stage) source.getScene().getWindow();
	    Main.setRoot("ProfMain");
    }
    
    public void valider()
    {
    	if(al.size()>0)
    	{
        	DBManager.updateNoteTP(al.get(current).id_matiere,al.get(current).CNE, Integer.parseInt(noteTP_tf.getText()));
        	al.get(current).note_tp=Integer.parseInt(noteTP_tf.getText());
        	Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("mis � jour!");
     
            alert.showAndWait();
    	}
    }
}
