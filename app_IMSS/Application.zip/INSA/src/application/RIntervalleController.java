package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class RIntervalleController {
	
	@FXML
    private VBox myVbox;
	
    @FXML
    private Label moyenne;

    @FXML
    private Label validation;
    
    @FXML
    private HBox myHView;
    
    @FXML
    private ComboBox<Matiere> combo1;
    
    @FXML
    private TextField TF1;
    
    @FXML
    private Label nom;

    @FXML
    private Label prenom;
    
    @FXML
    private Spinner<Integer> min;

    @FXML
    private Spinner<Integer> max;
    
    public static Filiere filiere=null;
    public static Semestre semestre=null;
    public static ArrayList<Etudiant> al=null;
    int current =0;
    
    public void initialize()
    {
    	al=DBManager.getEtudiants(filiere.id);
    	current=0;
    	
    	
    	SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 20, 0);
    	min.setValueFactory(valueFactory);
    	
    	SpinnerValueFactory<Integer> valueFactory1 = //
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 20, 20);
 
    	max.setValueFactory(valueFactory1);
    	
    	load(0);
    	loadCombo1();
    	
    }

	private void load(int index) {
		
		if(al!=null)
    	{
    	    ArrayList<Evaluation> al2=DBManager.getEvaluations(filiere.id, semestre.id,al.get(index).CNE);

    	    TableView tableView = new TableView();
    		
    		TableColumn<ModeleResultat, Integer> column0 = new TableColumn<>("Module");
            column0.setCellValueFactory(new PropertyValueFactory<>("module"));
            
            TableColumn<ModeleResultat, String> column1 = new TableColumn<>("Matiere");
            column1.setCellValueFactory(new PropertyValueFactory<>("matiere"));
            
            TableColumn<ModeleResultat, Integer> column2 = new TableColumn<>("note matiere");
            column2.setCellValueFactory(new PropertyValueFactory<>("note_matiere"));

            TableColumn<ModeleResultat, Integer> column3 = new TableColumn<>("note module");
            column3.setCellValueFactory(new PropertyValueFactory<>("note_module"));
            
            TableColumn<ModeleResultat, String> column4 = new TableColumn<>("Validation");
            column4.setCellValueFactory(new PropertyValueFactory<>("validation"));
            
                        
            tableView.getColumns().add(column0);
            tableView.getColumns().add(column1);
            tableView.getColumns().add(column2);
            tableView.getColumns().add(column3);
            tableView.getColumns().add(column4);
            

            float moy=DBManager.getNoteSemestre(al.get(index).CNE,semestre.id);
            if(  moy<((float) min.getValue()) ||  moy>((float)max.getValue()))
        	{
            	if((current+1)<al.size())
            	{
            		current++;
            		load(current);
            		return;
            	}
            	else
            	{
            		
                    return;
            	}
            		
        	}
            
            for(int i=0;i<al2.size();i++)
            {
            	Matiere m=DBManager.getMatiere(al2.get(i).id_matiere);
            	Module mo=DBManager.getModule(m.id_module);
            	float f=DBManager.getNoteModule(al2.get(i).CNE,mo.id);
            	float n=(al2.get(i).note_ecrit*m.coefecrit+al2.get(i).note_tp*m.coeftp)/(m.coefecrit+m.coeftp);
            	ModeleResultat mr=new ModeleResultat(mo.nom, m.nom, n, f);
            	tableView.getItems().add(mr);
            }
            
            
            moyenne.setText(moy+"");
            validation.setText(moy<10?"Non Valid�":"Valid�");
            myVbox.getChildren().clear();
            myVbox.getChildren().add(tableView);
            nom.setText(al.get(index).nom);
            prenom.setText(al.get(index).prenom);

    	}
		
	}
	
	public void next()
	{
		myHView.setVisible(false);
		if(current+1<al.size())
		{
			current++;
			load(current);
		}
	}
	
	public void prev()
	{
		myHView.setVisible(false);
		if(current>0)
		{
			current--;
			load(current);
		}
	}
	
	public void Modifier()
	{
		myHView.setVisible(true);
	}
	
	public void loadCombo1()
	{
		ArrayList<Matiere> alf=DBManager.getMatieres(filiere.id,semestre.id);
		combo1.getItems().clear();
    	combo1.getItems().addAll(alf);
	}
	
	public void Enregistrer()
	{
		if(TF1.getText().isEmpty() || combo1.getSelectionModel().getSelectedItem()==null)
		{
			Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez remplir les donn�es!");
     
            alert.showAndWait();
		}
		else
		{
			DBManager.updateNoteEcrit(combo1.getSelectionModel().getSelectedItem().id, al.get(current).CNE, Integer.parseInt(TF1.getText()));
			DBManager.updateNoteTP(combo1.getSelectionModel().getSelectedItem().id, al.get(current).CNE, Integer.parseInt(TF1.getText()));
			load(current);
		}
	}
	
	public void quit(ActionEvent actionEvent) throws IOException
	{
    	Node  source = (Node)  actionEvent.getSource(); 
	    Stage stage  = (Stage) source.getScene().getWindow();
	    Main.setRoot("CordiMain");

	}
	
	public void filtrer()
	{
		current=0;
		moyenne.setText("");
        validation.setText("");
        myVbox.getChildren().clear();
        nom.setText("");
        prenom.setText("");
		load(current);
	}
    

}
