package application;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;



public class CordiMainController {

	@FXML
    private ComboBox<Filiere> comboFilliere;

    @FXML
    private ComboBox<Semestre> comboSemestre;

    public static Filiere filiere=null;
    public static Semestre semestre=null;
    
    
    public void initialize(){
    	loadFilieres();
    	loadSemestres();
    }
    
    public void loadFilieres()
    {
    	ArrayList<Filiere> al=DBManager.getFilieres();
    	comboFilliere.getItems().clear();
    	comboFilliere.getItems().addAll(al);

    }
    
    public void loadSemestres()
    {
    	ArrayList<Semestre> al=DBManager.getSemestres();
    	comboSemestre.getItems().clear();
    	comboSemestre.getItems().addAll(al);

    }
    
    public void Valider()
    {
    	filiere=comboFilliere.getSelectionModel().getSelectedItem();
    	semestre=comboSemestre.getSelectionModel().getSelectedItem();
    }
    
    public void resultatParIntervalle(ActionEvent actionEvent) throws IOException
    {
    	if(filiere!=null && semestre!=null)
    	{
        	RIntervalleController.filiere=CordiMainController.filiere;
        	RIntervalleController.semestre=CordiMainController.semestre;
        	
        	Node  source = (Node)  actionEvent.getSource(); 
		    Stage stage  = (Stage) source.getScene().getWindow();
		    Main.setRoot("RIntervalle");
    	}
    	else
    	{
    		Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez d'abord choisir une filiere et un semestre!");
     
            alert.showAndWait();
    	}
    	
    }
    
    public void affichage(ActionEvent actionEvent) throws IOException
    {
    	if(filiere!=null && semestre!=null)
    	{
    		ResultatSemestreController.filiere=CordiMainController.filiere;
    		ResultatSemestreController.semestre=CordiMainController.semestre;
        				
			Stage stage=new Stage();
	    	FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ResultatSemestre.fxml"));
	    	fxmlLoader.load(); //to invoke the initialize methode
	    	ResultatSemestreController rsc=fxmlLoader.getController();
	    	rsc.print();

    	}
    	else
    	{
    		Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez d'abord choisir une filiere et un semestre!");
     
            alert.showAndWait();
    	}
    }
    
    
    
    
}
