package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ProfLoginController {
	
	@FXML
    private TextField idTF;

    @FXML
    private PasswordField pwTF;

    @FXML
	public void Connection(ActionEvent actionEvent) throws IOException
	{
		User u=DBManager.getUser(Integer.parseInt(idTF.getText()));
		if(u!=null)
		{
			if(u.mdp.equals(pwTF.getText()))
			{
				if(!u.role.equals("prof"))
				{
					Alert alert = new Alert(AlertType.ERROR);
		            alert.setTitle("Erreur");
		            alert.setHeaderText(null);
		            alert.setContentText("Vous n'etes pas autoris�!");
		     
		            alert.showAndWait();
				}
				else
				{
					Node  source = (Node)  actionEvent.getSource(); 
				    Stage stage  = (Stage) source.getScene().getWindow();
				    Main.setRoot("ProfMain");
				}
			}
			else
			{
				Alert alert = new Alert(AlertType.ERROR);
	            alert.setTitle("Erreur");
	            alert.setHeaderText(null);
	            alert.setContentText("Mot de Passe incorrect!");
	     
	            alert.showAndWait();
			}
		}
		else
		{
			Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Utilisateur n'existe Pas!");
     
            alert.showAndWait();
		}
	}

}
