package application;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.print.PrinterJob;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class ResultatSemestreController {
	
    public static Filiere filiere;

	public static Semestre semestre;

	@FXML
    private HBox myHbox;
	
	@FXML
    private VBox myVbox2;
	
    @FXML
    private Label titile;
    
    ArrayList<Etudiant> al=null;
    
    public void initialize()
    {
    	al=DBManager.getEtudiants(filiere.id);
    	if(al!=null)
    	{
    	    TableView tableView = new TableView();
    		
    		TableColumn<ModeleAffichage, Integer> column0 = new TableColumn<>("CNE");
            column0.setCellValueFactory(new PropertyValueFactory<>("CNE"));
            
            TableColumn<ModeleAffichage, String> column1 = new TableColumn<>("Nom");
            column1.setCellValueFactory(new PropertyValueFactory<>("nom"));
            
            TableColumn<ModeleAffichage, String> column2 = new TableColumn<>("Pr�nom");
            column2.setCellValueFactory(new PropertyValueFactory<>("prenom"));

            TableColumn<ModeleAffichage, Float> column3 = new TableColumn<>("Note");
            column3.setCellValueFactory(new PropertyValueFactory<>("note"));
            
            TableColumn<ModeleAffichage, String> column4 = new TableColumn<>("Validation");
            column4.setCellValueFactory(new PropertyValueFactory<>("validation"));
            
                        
            tableView.getColumns().add(column0);
            tableView.getColumns().add(column1);
            tableView.getColumns().add(column2);
            tableView.getColumns().add(column3);
            tableView.getColumns().add(column4);
            
            for(int i=0;i<al.size();i++)
            {
            	Etudiant e=DBManager.getEtudiant(al.get(i).CNE);
                float moy=DBManager.getNoteSemestre(al.get(i).CNE,semestre.id);
            	ModeleAffichage ma=new ModeleAffichage(e.CNE,e.nom,e.prenom,moy);
            	tableView.getItems().add(ma);
            }

            myHbox.getChildren().add(tableView);
            titile.setText("Resultat "+filiere.nom+"/"+semestre.nom);
            

            
    	}
    }
    
    public void print()
    {
    	PrinterJob job = PrinterJob.createPrinterJob();
        if(job != null){

		  job.printPage(myVbox2);
		  job.endJob();
        }
    }

}
