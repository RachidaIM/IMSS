package application;


import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;

public class WelcomeController {

	public void connectProf(ActionEvent actionEvent) throws IOException
	{
		Node  source = (Node)  actionEvent.getSource(); 
	    Stage stage  = (Stage) source.getScene().getWindow();
	    Main.setRoot("ProfLogin");

	    stage.setResizable(false);
	}
	
	public void connectCoordi(ActionEvent actionEvent) throws IOException
	{
		Node  source = (Node)  actionEvent.getSource(); 
	    Stage stage  = (Stage) source.getScene().getWindow();
	    Main.setRoot("CordiLogin");

	    stage.setResizable(false);
	}
}
