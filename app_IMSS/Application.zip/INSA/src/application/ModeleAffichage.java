package application;

public class ModeleAffichage {

	int CNE;
	String nom;
	String prenom;
	String validation;
	float note;
	
	public ModeleAffichage(int cNE, String nom, String prenom, float note) {
		super();
		CNE = cNE;
		this.nom = nom;
		this.prenom = prenom;
		this.note = note;
		
		if(note>=10) validation="Valid�";
		else validation="Non Valid�";
	}

	public int getCNE() {
		return CNE;
	}

	public void setCNE(int cNE) {
		CNE = cNE;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public float getNote() {
		return note;
	}

	public void setNote(float note) {
		this.note = note;
	}
	
	public String getValidation() {
		return validation;
	}

	public void setValidation(String validation) {
		this.validation = validation;
	}
	
}
