package application;

public class Evaluation {
	int CNE,note_ecrit,note_tp,id_matiere,presence_tp;

	public Evaluation(int cNE, int note_ecrit, int note_tp, int id_matiere, int presence_tp) {
		super();
		CNE = cNE;
		this.note_ecrit = note_ecrit;
		this.note_tp = note_tp;
		this.id_matiere = id_matiere;
		this.presence_tp = presence_tp;
	}

}
