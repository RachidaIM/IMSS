package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DBManager {
	
	public static Connection conn = null;
    public static String dbName="Student1";
    public static String userName="root";
    public static String password="nouhaila@**";
    public static String host="localhost";

    public static Connection connect()
    {
        try {
            conn =DriverManager.getConnection("jdbc:mysql://"+host+"/"+dbName+"?" + "user="+userName+"&password="+password);
            System.out.println("Connected To Database");
        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        return conn;
    }
    
	public static User getUser(int id)
	{
		User u=null;
    	try {
			  String query = "SELECT * from user where IDuser=?";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  if(rs.next())
			  {
				  u=new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
			  }
			  
    	}
    	catch(Exception ex)
    	{
        	System.out.println("Error: "+ex);
    	}
    	
    	return u;
	}

	public static ArrayList<Filiere> getFilieres() {
		ArrayList<Filiere> al=new ArrayList<Filiere>();
    	try {
			  String query = "SELECT * from filiere";
			  PreparedStatement ps = conn.prepareStatement(query);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Filiere e=new Filiere(rs.getInt(1),rs.getString(2));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}
	
	public static Filiere getFiliere(int id)
	{
		Filiere f=null;
    	try {
			  String query = "SELECT * from filiere where idfiliere=?";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  if(rs.next())
			  {
				  f=new Filiere(rs.getInt(1),rs.getString(2));
			  }
			  
    	}
    	catch(Exception ex)
    	{
        	System.out.println("Error: "+ex);
    	}
    	
    	return f;
	}

	public static ArrayList<Semestre> getSemestres() {
		ArrayList<Semestre> al=new ArrayList<Semestre>();
    	try {
			  String query = "SELECT * from semestre";
			  PreparedStatement ps = conn.prepareStatement(query);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Semestre e=new Semestre(rs.getInt(1),rs.getString(2));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}

	public static ArrayList<Module> getModules(int id_filiere, int id_semestre) {
		ArrayList<Module> al=new ArrayList<Module>();
    	try {
			  String query = "SELECT IDmodule , semestre_idsemestre , filiereid , Nommodule  from module where filiereid=? and semestre_idsemestre=?";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id_filiere);
			  ps.setInt(2, id_semestre);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Module e=new Module(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}

	public static ArrayList<Matiere> getMatieres(int id_module) {
		ArrayList<Matiere> al=new ArrayList<Matiere>();
    	try {
			  String query = "SELECT IDmatiere , coeftp , coefecrit , module_IDmodule ,nbr_tp , Nommatiiere  from matiere where module_IDmodule=? ";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id_module);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Matiere e=new Matiere(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getString(6));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}
	
	public static ArrayList<Matiere> getMatieres( int id_filiere,int id_semestre) {
		
		ArrayList<Matiere> al=new ArrayList<Matiere>();
    	try {
			  String query = "SELECT IDmatiere , coeftp , coefecrit , module_IDmodule ,nbr_tp , Nommatiiere  \r\n" + 
			  		"from matiere m, module mo\r\n" + 
			  		"where mo.semestre_idsemestre=? and mo.filiereid=? and m.module_IDmodule=mo.IDmodule ";
			  
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id_semestre);
			  ps.setInt(2, id_filiere);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Matiere e=new Matiere(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getString(6));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}

	public static void updateMatiere(int id_matiere,int nbr_tp, int coef_ecrit, int coef_tp) {

		String query = "update matiere set nbr_tp=? , coefecrit=? , coeftp=? where IDmatiere=?";
        
        try {
        	// create the mysql insert preparedstatement
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setInt(1, nbr_tp);
            preparedStmt.setInt(2, coef_ecrit);
            preparedStmt.setInt(3, coef_tp);
            preparedStmt.setInt(4, id_matiere);
            
            // execute the preparedstatement
            preparedStmt.execute();
           
        }
        catch(Exception ex)
        {
        	System.out.println("Error updating : " + ex.getMessage());
        }

	}
	
	public static ArrayList<Evaluation> getEvaluations(int id_matiere) {
		ArrayList<Evaluation> al=new ArrayList<Evaluation>();
    	try {
			  String query = "SELECT CNE , Noteecrit , Notetp , id_matiere ,presence_tp   from evaluation where id_matiere=? ";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id_matiere);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Evaluation e=new Evaluation(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}
	
	public static ArrayList<Evaluation> getEvaluations(int id_filiere,int id_semestre,int CNE) {
		ArrayList<Evaluation> al=new ArrayList<Evaluation>();
    	try {
			  String query = "SELECT CNE , Noteecrit , Notetp , id_matiere ,presence_tp  \r\n" + 
			  		"from evaluation e, filiere f, semestre s, matiere ma , module m  , filiere_has_semestre fhs\r\n" + 
			  		"where CNE=? and f.idfiliere=? and s.idsemestre=? and f.idfiliere=m.filiereid and m.IDmodule=ma.module_IDmodule and e.id_matiere=ma.IDmatiere and s.idsemestre=fhs.semestre_idsemestre and f.idfiliere=fhs.filiere_idfiliere";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, CNE);
			  ps.setInt(2, id_filiere);
			  ps.setInt(3, id_semestre);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Evaluation e=new Evaluation(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}
	
	public static ArrayList<Etudiant> getEtudiants(int id_filiere) {
		ArrayList<Etudiant> al=new ArrayList<Etudiant>();
    	try {
			  String query = "SELECT idetudiant, NomEtudiant,PrenomEtudiant,filiere_idfiliere from etudiant where filiere_idfiliere=?";
    		  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id_filiere);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next())
			  {
				  Etudiant e=new Etudiant(rs.getInt(1),rs.getInt(4),rs.getString(2),rs.getString(3));
				  al.add(e);
			  }
			  
	  	}
	  	catch(Exception ex)
	  	{
	      	System.out.println("Error: "+ex);
	  	}
    	return al;
	}

	public static Etudiant getEtudiant(int cNE) {
		Etudiant e=null;
    	try {
			  String query = "SELECT idetudiant, NomEtudiant,PrenomEtudiant,filiere_idfiliere from etudiant where idetudiant=?";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, cNE);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  if(rs.next())
			  {
				  e=new Etudiant(rs.getInt(1),rs.getInt(4),rs.getString(2),rs.getString(3));
			  }
			  
    	}
    	catch(Exception ex)
    	{
        	System.out.println("Error: "+ex);
    	}
    	
    	return e;
	}
	
	public static Matiere getMatiere(int id) {
		Matiere m=null;
    	try {
			  String query = "SELECT * from matiere where IDmatiere=?";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  if(rs.next())
			  {
				  m=new Matiere(rs.getInt(1), rs.getInt(3), rs.getInt(4), rs.getInt(6),rs.getInt(7) ,rs.getString(2));
			  }
			  
    	}
    	catch(Exception ex)
    	{
        	System.out.println("Error: "+ex);
    	}
    	
    	return m;
	}
	
	public static void updatePresence(int id_matiere,int CNE, int presence_tp) {

		String query = "update evaluation set presence_tp=?  where id_matiere=? and CNE= ?";
        try {
        	
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setInt(1, presence_tp);
            preparedStmt.setInt(2, id_matiere);
            preparedStmt.setInt(3, CNE);
            
            preparedStmt.execute();
            
            if(presence_tp==0)
            {
            	updateNoteTP(id_matiere,CNE, -2);
            }
           
        }
        catch(Exception ex)
        {
        	System.out.println("Error updating : " + ex.getMessage());
        }

	}
	
	public static void updateNoteTP(int id_matiere, int CNE, int note) {

		String query = "update evaluation set Notetp=?  where id_matiere=? and CNE= ?";
        
        try {
        	
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setInt(1, note);
            preparedStmt.setInt(2, id_matiere);
            preparedStmt.setInt(3, CNE);
            
           
            preparedStmt.execute();
           
        }
        catch(Exception ex)
        {
        	System.out.println("Error updating : " + ex.getMessage());
        }

	}

	public static void updateNoteEcrit(int id_matiere, int CNE, int note) {
		
		String query = "update evaluation set Noteecrit=?  where id_matiere=? and CNE= ?";
        
        try {
        	
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setInt(1, note);
            preparedStmt.setInt(2, id_matiere);
            preparedStmt.setInt(3, CNE);
            
         
            preparedStmt.execute();
           
        }
        catch(Exception ex)
        {
        	System.out.println("Error updating : " + ex.getMessage());
        }
		
	}

	public static Module getModule(int id) {
		
		Module m=null;
    	try {
			  String query = "SELECT * from module where IDmodule=?";
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, id);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  if(rs.next())
			  {
				  m=new Module(rs.getInt(1), rs.getInt(3), rs.getInt(4), rs.getString(2));
			  }		  
    	}
    	catch(Exception ex)
    	{
        	System.out.println("Error: "+ex);
    	}
    	
    	return m;
	}

	public static float getNoteModule(int cne, int id_module) {
		float f=0f;
    	try {
			  String query = "select AVG((Noteecrit*coefecrit+Notetp*coeftp)/(coeftp+coefecrit)) as note\r\n" + 
			  		"from module mo , matiere ma , evaluation e\r\n" + 
			  		"where mo.IDmodule=ma.module_IDmodule and e.id_matiere=ma.iDmatiere and CNE=? and mo.IDmodule=?";
			  
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, cne);
			  ps.setInt(2, id_module);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  if(rs.next())
			  {
				  f=rs.getFloat(1);
			  }		  
    	}
    	catch(Exception ex)
    	{
        	System.out.println("Error: "+ex);
    	}
    	
    	return f;
	}

	public static float getNoteSemestre(int cne , int id_semestre) {
		float f=0f;
    	try {
			  String query = "select AVG(note)\r\n" + 
			  		"from (select AVG((Noteecrit*coefecrit+Notetp*coeftp)/(coeftp+coefecrit)) as note\r\n" + 
			  		"from module mo , matiere ma , evaluation e , semestre s , filiere_has_semestre fhs\r\n" + 
			  		"where mo.IDmodule=ma.module_IDmodule and e.id_matiere=ma.iDmatiere and CNE=? and s.idsemestre=? \r\n" + 
			  		"group by mo.IDmodule) a";
			  
			  PreparedStatement ps = conn.prepareStatement(query);
			  ps.setInt(1, cne);
			  ps.setInt(2, id_semestre);
			  
			  ResultSet rs = ps.executeQuery();
			  
			  if(rs.next())
			  {
				  f=rs.getFloat(1);
			  }		  
    	}
    	catch(Exception ex)
    	{
        	System.out.println("Error: "+ex);
    	}
    	
    	return f;
	}

	
	
	



}
