package application;

public class Module {

	int id , id_semestre , id_filiere;
	String nom;
	
	public Module(int id, int id_semestre, int id_filiere, String nom) {
		super();
		this.id = id;
		this.id_semestre = id_semestre;
		this.id_filiere = id_filiere;
		this.nom = nom;
	}

	@Override
	public String toString() {
		return nom;
	}
	
	
}
