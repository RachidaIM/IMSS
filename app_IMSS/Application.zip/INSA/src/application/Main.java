package application;
	
import java.io.IOException;
import java.sql.Connection;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	
    private static Scene scene;

	@Override
	public void start(Stage primaryStage) {
		Connection conn=DBManager.connect();
        if(conn==null)
        {
        	Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Test Connection");
            alert.setHeaderText(null);
            alert.setContentText("Connection to the database failed!");
     
            alert.showAndWait();
            return;
        }
		try {
			BorderPane root = new BorderPane();
			scene = new Scene(loadFXML("Welcome"), 700, 400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }
	
	public static void main(String[] args) {
		launch(args);
	}
	
	static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }
}
