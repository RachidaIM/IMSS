package application;

public class Etudiant {

	int CNE, id_filiere;
	String nom,prenom;
	
	public int getCNE() {
		return CNE;
	}

	public void setCNE(int cNE) {
		CNE = cNE;
	}

	public int getId_filiere() {
		return id_filiere;
	}

	public void setId_filiere(int id_filiere) {
		this.id_filiere = id_filiere;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Etudiant(int cNE, int id_filiere, String nom, String prenom) {
		super();
		CNE = cNE;
		this.id_filiere = id_filiere;
		this.nom = nom;
		this.prenom = prenom;
	}
	
	public int hi()
	{
		return 2;
	}
	
	
}
